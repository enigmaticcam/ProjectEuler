﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Euler_Logic.Problems {
    public class Problem178 : ProblemBase {
        public override string ProblemName {
            get { return "178: Step Numbers"; }
        }

        public override string GetAnswer() {
            return "";
        }

        private void Solve1(int maxDigit) {
            
        }
    }
}
